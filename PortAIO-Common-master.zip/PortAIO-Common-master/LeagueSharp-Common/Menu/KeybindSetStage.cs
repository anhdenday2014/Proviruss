﻿namespace LeagueSharp.Common
{
    enum KeybindSetStage
    {
        Keybind1,

        Keybind2,

        NotSetting
    }
}