﻿namespace LeagueSharp.SDK.Core.Wrappers.Spells.SpellTypes
{
    class Targeted
    {
    }
}